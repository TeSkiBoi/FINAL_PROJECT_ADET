package ui;
import javax.swing.*;
import java.awt.*;

public class TransactionPanel extends JPanel {
    public TransactionPanel() {
        setLayout(new BorderLayout());
        add(new JLabel("Transaction Management (Coming Soon)", SwingConstants.CENTER), BorderLayout.CENTER);
    }
}
